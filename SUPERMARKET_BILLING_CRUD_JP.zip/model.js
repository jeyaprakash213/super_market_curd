const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProductSchema = new Schema({
    productName: {
        type: String,
        required: true
    },
    rate: {
        type: Number,
        required: true
    },
    date: { type: Date, default: Date.now }


});

// Main List Parameters:
const purchaseSchema = new Schema({
    date: { type: Date, default: Date.now },
    customerName: {
        type: String,
        required: true
    },
    purchaseNumber: {
        type: String,
        required: true
    },
    totalAmount: {
        type: Number,
    },
    remark: String
    // products: {
    //     productName: {
    //         type: String,
    //     },
    //     quantity: {
    //         type: Number,

    //     },
    //     rate: {
    //         type: Number,

    //     },
    //     amount: {
    //         type: Number,

    //     }
    // }
});


// Sub List Parameters:
const PurchasedSchema = new Schema({
    date: { type: Date, default: Date.now },
    productName: {
        type: String,
        required: true
    },
    purchaseNumber: {
        type: String
    },
    quantity: {
        type: Number,
        required: true
    },
    rate: {
        type: Number,
        required: true
    },
    amount: {
        type: Number
    }
});


const Product = mongoose.model('smproduct', ProductSchema);
const mainPurchase = mongoose.model('smpurchase', purchaseSchema);
const subPurchased = mongoose.model('smpurchased', PurchasedSchema);

module.exports = { Product, mainPurchase, subPurchased };
