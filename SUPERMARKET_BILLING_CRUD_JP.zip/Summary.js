
const { Product, mainPurchase, subPurchased } = require('./model');

module.exports = {

    getAll: function (req, res, next) {
        let productQuery = {};
        console.log(req.body)
        productQuery.productName = req.body.productName;

        const pipeline = [
            {
                $match: {
                    productName: req.body.productName
                }
            },
            {
                $group: {
                    _id: req.body.productName,
                    totalQuantity: { $sum: "$quantity" },
                    totalAmount: { $sum: { $multiply: ["$quantity", "$rate"] } }
                }
            }
        ];

        subPurchased.aggregate(pipeline)
            .then(result => {
                console.log(result);
                res.status(200).send({
                    Products: result
                });
            })
            .catch(error => {
                console.error(error);
                // Handle errors here
            });
    }
};