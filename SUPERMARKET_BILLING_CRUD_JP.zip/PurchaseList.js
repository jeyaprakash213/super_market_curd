
const { Product, mainPurchase, subPurchased } = require('./model');

module.exports = {
    getById: function (req, res, next) {
        let productQuery = {};
        productQuery._id = req.params.id;
        subPurchased.find(productQuery, function (err, Products) {
            console.log("jjjjjjjjj", Products)
            if (err) {
                next(err);
            } else {
                res.status(200).send({
                    Products: Products
                });
            }
        });
    },
    getAll: function (req, res, next) {
        let productQuery = {};
        subPurchased.find(productQuery, function (err, Products) {
            console.log("jjjjjjjjj", Products)
            if (err) {
                next(err);
            } else {
                res.status(200).send({
                    Products: Products
                });
            }
        });
    },
    deleteById: function (req, res, next) {
        res.status(200).send({ message: "deleted successfully!!!" });
        let productQuery = {};
        console.log(req.params)
        console.log(req.body)
        productQuery.productName = req.params.productName;
        subPurchased.findOneAndRemove(productQuery, function (err, productInfo) {
            if (err) next(err);
            else {
                res.status(200).send({ message: "deleted successfully!!!" });
            }
        });
    },
    responce: function (req, res, next) {
        res.status(200).send({ message: "deleted successfully!!!" });
    }
};