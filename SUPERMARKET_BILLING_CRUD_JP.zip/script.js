// server.js

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;

// Connect to MongoDB
mongoose.connect('mongodb+srv://admin:admin123@cluster0.pn9ywl0.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// Define Purchase schema
const PurchaseSchema = new mongoose.Schema({
    date: Date,
    customerName: String,
    purchaseNumber: String,
    totalAmount: Number,
    remark: String,
    products: [{ name: String, quantity: Number, rate: Number, amount: Number }],
});

const Purchase = mongoose.model('Purchaseeee', PurchaseSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Handle POST request for new purchase entry
app.post('/api/purchase', (req, res) => {
    const purchaseData = req.body;

    // Create new Purchase document
    const newPurchase = new Purchase({
        date: purchaseData.date,
        customerName: purchaseData.customerName,
        purchaseNumber: purchaseData.purchaseNumber,
        totalAmount: purchaseData.totalAmount,
        remark: purchaseData.remark,
        products: purchaseData.products,
    });

    // Save the purchase to MongoDB
    newPurchase.save((err, savedPurchase) => {
        if (err) {
            console.error(err);
            res.status(500).send('Error saving purchase');
        } else {
            res.status(200).send('Purchase saved successfully', savedPurchase);
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
