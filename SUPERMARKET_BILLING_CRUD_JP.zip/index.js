const express = require('express');
const connectDB = require('./db');
const PurchaseController = require('./PurchaseList');
const productController = require('./Product');
const SummaryController = require('./Summary');
const app = express();
const PORT = process.env.PORT || 3000;
const path = require('path');
const axios = require('axios');
const cors = require('cors');

// Connect to MongoDB
connectDB();



// Express middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'))

// used apis
app.post('/MainList/product', productController.Main);
app.post('/SubList/product', productController.Sub);
app.get('/MainList/purchaseList', productController.getAll);
app.get('/purchaseList', PurchaseController.getAll);
app.post("/Summary", SummaryController.getAll);


// New Purchase Entry Page
app.post('/product', productController.create);

// Purchase List Page
app.get('/singlepurchase', PurchaseController.getById);
app.delete("/purchase/delete", PurchaseController.deleteById);
app.get('/singleMainlist', PurchaseController.getById);


// Product Summary Page  



app.get("/", (req, res) => {
    res.set({
        "Allow-acces-Allow-Origin": '*'
    })
    return res.redirect('index.html')
});



// Server start
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});