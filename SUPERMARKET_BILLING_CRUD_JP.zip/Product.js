
const { Product, mainPurchase, subPurchased } = require('./model');

module.exports = {
    create: function (req, res, next) {
        Product.findOne(
            { productName: req.body.productName },
            function (err, productInfo) {
                console.log(productInfo, "productInfo");
                if (!productInfo) {
                    const product = {};
                    product.productName = req.body.productName;
                    // product.quantity = req.body.quantity;
                    product.rate = req.body.rate;

                    // if (req.body.rate) {
                    //     req.body.amount = req.body.rate * req.body.quantity
                    // }

                    Product.create(product, function (err, result) {
                        if (err) next(err);
                        else
                            res.status(200).send({ message: "product added successfully!!!" });
                    });
                } else {
                    res.status(422).send({ message: "product already exists" });
                }
            }
        );
    },
    Main: function (req, res, next) {
        console.log(req, "reqqqqqqqqqqqqqqq");
        mainPurchase.findOne(
            { customerName: req.body.customerName },
            function (err, productInfo) {
                console.log(productInfo, "customerName");
                if (!productInfo || productInfo) {
                    const product = {};
                    product.customerName = req.body.customerName;
                    product.purchaseNumber = req.body.purchaseNumber
                    product.remark = req.body.remark;

                    product.totalAmount = req.body.totalAmount;
                    mainPurchase.create(product, function (err, result) {
                        if (err) next(err);
                        else
                            res.status(200).send({ message: "Customer added successfully!!!" });
                    });
                } else {
                    res.status(422).send({ message: "Please enter currect values" });
                }
            }
        );
    },
    Sub: function (req, res, next) {
        console.log("jjjjjjjjjj", req)
        subPurchased.findOne(
            { productName: req.body.productName },
            function (err, productInfo) {
                console.log(productInfo, "productInfooooo");
                if (!productInfo || productInfo) {
                    const product = {};
                    product.productName = req.body.productName;
                    product.quantity = req.body.quantity;
                    product.rate = req.body.rate;
                    product.purchaseNumber = req.body.purchaseNumber;
                    if (req.body.rate && req.body.quantity) {
                        product.amount = req.body.rate * req.body.quantity
                    }

                    subPurchased.create(product, function (err, result) {
                        if (err) next(err);
                        else
                            res.status(200).send({ Products: result });
                    });
                } else {
                    res.status(422).send({ message: "product already exists" });
                }
            }
        );
    },
    getById: function (req, res, next) {
        let productQuery = {};
        productQuery._id = req.params.id;
        mainPurchase.find(productQuery, function (err, Products) {
            console.log("jjjjjjjjj", Products)
            if (err) {
                next(err);
            } else {
                res.status(200).send({
                    message: "Products list found!!!",
                    data: { Products: Products },
                });
            }
        });
    },
    getAll: function (req, res, next) {
        let productQuery = {};
        mainPurchase.find(productQuery, function (err, Products) {
            console.log("jjjjjjjjj", Products)
            console.log("jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj")
            if (err) {
                next(err);
            } else {
                res.status(200).send({
                    Products: Products
                });
            }
        });
    }
    // newPurchaseEntry: function (req, res, next) {
    //     mainPurchase.findOne(
    //         { productName: req.body.productName },
    //         function (err, productInfo) {
    //             console.log(productInfo, "productInfo");
    //             if (!productInfo || productInfo) {
    //                 console.log(req.body, "req.body");
    //                 const product = { products: {} };
    //                 product.customerName = req.body.customerName;
    //                 product.purchaseNumber = req.body.purchaseNumber;
    //                 product.remark = req.body.remark;
    //                 product.quantity = req.body.quantity;
    //                 product.rate = req.body.rate;
    //                 product.products.productName = req.body.productName
    //                 product.products.quantity = req.body.quantity
    //                 product.products.rate = req.body.rate


    //                 if (req.body.rate && req.body.quantity) {
    //                     product.products.amount = req.body.rate * req.body.quantity
    //                 }

    //                 mainPurchase.create(product, function (err, result) {
    //                     if (err) { next(err); }
    //                     else {
    //                         res.status(200).send({ message: "product added successfully!!!" });

    //                     }

    //                 });
    //             } else {
    //                 res.status(422).send({ message: "product already exists" });
    //             }
    //         }
    //     );
    // }
};