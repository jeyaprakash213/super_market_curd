
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
// import { ProductService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent implements OnInit {
  productName: any;
  rate: any;
  amount: any;
  quantity: any;
  purchaseNumber: any;
  customerName: any;
  date: any;
  // ngOnInit(): void {
  //   throw new Error('Method not implemented.');
  // }
  purchase: any = {};
  selectedProduct: any

  products: any[] = [];
  getSummery: any[] = [];
  purchaseAllData: any[] = [];
  purchaseItems: any[] = [];
  ProductArray: any[] = [];
  remark: any;
  totalAmount: any;

  constructor(private http: HttpClient) {
    this.getAllProducts();
    this.getAllpurchaseProducts()
  }

  getAllProducts() {
    this.http.get("http://localhost:3000/purchaseList")
      .subscribe((resultData: any) => {
        console.log("resultData", resultData);
        this.products = resultData.Products;
        // this.selectedProduct = resultData.Products.productName
      });
  }


  getAllpurchaseProducts() {
    this.http.get("http://localhost:3000/MainList/purchaseList")
      .subscribe((resultData: any) => {
        console.log("getAllpurchaseProducts", resultData);
        this.purchaseAllData = resultData.Products;
        // this.selectedProduct = resultData.Products.productName
      });
  }


  ngOnInit(): void {
    this.getAllProducts();
    this.getAllpurchaseProducts()
  }

  // loadProducts() {
  //   this.productService.getProducts().subscribe((data: any[]) => {
  //     this.products = data;
  //   });
  // }


  addProduct() {

    console.log(JSON.stringify(this.selectedProduct))
    let bodyData = {
      "productName": this.selectedProduct,
      "rate": this.rate,
      "quantity": this.quantity,
      "amount": 10,
      "purchaseNumber": this.purchaseNumber
    };

    if (!this.selectedProduct && !this.quantity && !this.purchaseNumber && !this.rate) {
      alert("Enter all values")
      throw new Error("Enter all values");
    }

    this.ProductArray.map((val) => {
      if (val.productName == this.selectedProduct) {
        // this.selectedProduct = '';
        // this.rate = '';
        // this.amount = '';
        // this.quantity = '';
        // this.purchaseNumber = '';
        alert("Product already excits")
        window.location.reload();
      }
    })

    console.log("bodyData", bodyData)

    this.http.post("http://localhost:3000/SubList/product", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);

      this.ProductArray.push(resultData.Products)
      console.log("ProductArray", this.ProductArray);
      alert("Product add Successfully")
      this.getAllProducts();
      this.productName = '';
      this.selectedProduct = '';
      this.rate = '';
      this.amount = '';
      this.quantity = '';
      this.purchaseNumber = '';
      this.getAllpurchaseProducts()

    });

  }


  calculateTotalAmount(): number {
    let totalAmount = 0;
    for (let i = 0; i < this.ProductArray.length; i++) {
      totalAmount += this.ProductArray[i].amount;
    }
    return totalAmount;
  }


  setDelete() {
    // Logic to save purchase 
    this.ProductArray.shift()
    console.log("ProductArray", this.ProductArray);

    console.log(this.purchaseItems);
  }

  savePurchase() {
    console.log(JSON.stringify(this.selectedProduct))
    let bodyData = {
      "customerName": this.customerName,
      "totalAmount": this.calculateTotalAmount(),
      "remark": this.remark,
      "purchaseNumber": this.purchaseNumber
    };

    if (this.calculateTotalAmount() == 0) {
      alert("Enter all values")
      throw new Error("Enter all values");
    }
    if (!this.customerName) {
      alert("Enter all values")
      throw new Error("Enter all values");
    }


    console.log("bodyData", bodyData)

    this.http.post("http://localhost:3000/MainList/product", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);
      // this.ProductArray.push(resultData.Products)
      // console.log("ProductArray", this.ProductArray);
      alert("MainList add Successfully")
      this.getAllProducts();
      this.customerName = '';
      this.totalAmount = '';
      this.remark = '';
      this.amount = '';
      this.quantity = '';
      this.purchaseNumber = '';
      this.ProductArray = [];

      this.addProduct();
      this.getAllpurchaseProducts()
    });
  }

  generateSummary() {

    let bodyData = {
      "productName": this.selectedProduct
    };

    this.http.post("http://localhost:3000/Summary", bodyData)
      .subscribe((resultData: any) => {
        console.log("resultData", resultData);
        this.getSummery = resultData.Products;
        // this.selectedProduct = resultData.Products.productName
      });
  }


}
