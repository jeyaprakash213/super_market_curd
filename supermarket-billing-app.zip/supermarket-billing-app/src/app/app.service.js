import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { HttpService } from '../common/http.service';
import { HttpClient } from '@angular/common/http';
import { ProductService } from '@angular/common/http';